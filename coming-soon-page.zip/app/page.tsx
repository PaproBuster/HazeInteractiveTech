"use client"

import ComingSoonPage from "../coming-soon-page"

export default function SyntheticV0PageForDeployment() {
  return <ComingSoonPage />
}